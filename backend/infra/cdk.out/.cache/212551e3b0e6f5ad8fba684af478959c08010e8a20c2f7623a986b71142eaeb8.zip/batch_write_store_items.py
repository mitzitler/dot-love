########################################################
# Lambda Handler
########################################################
# cw_store_items = [
#     {
#         "product_name": "",
#         "price": "",
#         "product_type": "",
#         "quantity": "",
#     }
# ]
def handler(event, context):
    res = True

    return res
